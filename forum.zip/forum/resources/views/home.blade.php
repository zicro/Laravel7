@extends('layouts.app')

 @section('content')
    <h1>Home Page</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eum eveniet laborum, ex inventore cumque sint ipsam, nobis, iusto perferendis doloremque consequuntur. Ex tenetur expedita deserunt provident quidem animi cupiditate eum!</p>

@endsection
    