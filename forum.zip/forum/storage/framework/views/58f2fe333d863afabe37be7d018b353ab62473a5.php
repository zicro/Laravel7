

 <?php $__env->startSection('content'); ?>
    <h1>Home Page</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eum eveniet laborum, ex inventore cumque sint ipsam, nobis, iusto perferendis doloremque consequuntur. Ex tenetur expedita deserunt provident quidem animi cupiditate eum!</p>

<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\xLion\Desktop\FrontAndBackDev\Laravel7\forum\resources\views/home.blade.php ENDPATH**/ ?>