<div class="form-group">
    <label for="title">
        title
    </label>
    <input class="form-control" name="title" type="text" id="title" value="<?php echo e(old('title', $post->title ?? null )); ?>">
</div>
<div class="form-group">
    <label for="content">
        content
    </label>
    <textarea class="form-control" name="content" id="content"><?php echo e(old('content', $post->content ?? null)); ?></textarea>
</div>
<?php if($errors->any()): ?>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
    </ul>
<?php endif; ?><?php /**PATH C:\Users\xLion\Desktop\FrontAndBackDev\Laravel7\forum\resources\views/posts/form.blade.php ENDPATH**/ ?>