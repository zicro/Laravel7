

<?php $__env->startSection('content'); ?>
<h3><?php echo e($post->title); ?> </h3>
<p><?php echo e($post->content); ?></p>
    <em><?php echo e($post->created_at); ?></em>
<span>
    <?php if($post->active): ?>
    <span class="badge badge-success">active</span>
    <?php else: ?>
    <span class="badge badge-danger">disabled </span>    
    <?php endif; ?>
</span>


<?php if($post->comments->count() >0): ?>
    
<h3>Comments : </h3>
<?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="list-group-item">
<p><?php echo e($comment->content); ?></p>
<em><?php echo e($comment->created_at); ?></em>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php endif; ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\xLion\Desktop\FrontAndBackDev\Laravel7\forum\resources\views/posts/show.blade.php ENDPATH**/ ?>