

<?php $__env->startSection('content'); ?>

<nav class="nav nav-tabs nav-stacked my-5">
    <a class="nav-link  <?php if($tab == 'list'): ?> active <?php endif; ?> " href="/posts">List</a>
    <a class="nav-link  <?php if($tab == 'archive'): ?> active <?php endif; ?>" href="/posts/archive">Archive</a>
    <a class="nav-link  <?php if($tab == 'all'): ?> active <?php endif; ?>" href="/posts/all">All</a>
</nav>

<h2 style="color:#ccc;" class="text-center">Nombre de Posts : <?php echo e($posts->count()); ?></h2>

<h3>Post list : </h3>
    <ul class="list-group">    
        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <li class="list-group-item">
        
        <h3><a href="<?php echo e(route('posts.show', ['post' => $post->id])); ?>">
            <?php echo e($post->title); ?>

        </a></h3>

        <p><?php echo e($post->content); ?></p>
    <span class="badge badge-success">
        <?php if($post->comments_count == 0): ?>
            no Comment.
        <?php elseif($post->comments_count == 1): ?>
        <?php echo e($post->comments_count); ?> Comment
        <?php else: ?>
        <?php echo e($post->comments_count); ?> Comments   
        <?php endif; ?>
       </span>
    <em><?php echo e($post->updated_at->diffForHumans()); ?>, by <?php echo e($post->user->name); ?></em>
    <br >
    
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $post)): ?>
    <a class="btn btn-primary" href="<?php echo e(route('posts.edit', ['post' => $post->id])); ?>" >edit</a>
    <?php endif; ?>

    <?php if($post->deleted_at): ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('restore', $post)): ?>
    <form style="display:inline;" action="<?php echo e(url('/posts/'.$post->id.'/restore')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>
            <button type="submit" class="btn btn-success">
                restore</button>
        </form>
    <?php endif; ?>
            
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('forceDelete', $post)): ?>
        <form style="display:inline;" action="<?php echo e(url('/posts/'.$post->id.'/forcedelete')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-warning">
                    !Delete</button>
            </form>
            <?php endif; ?>
    <?php else: ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $post)): ?>
    <form style="display:inline;" action="<?php echo e(route('posts.destroy', ['post' => $post->id])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger">
                Delete</button>
        </form>
        <?php endif; ?>

    <?php endif; ?>
   
    </li>
    


        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <span class="badge badge-danger">There is no Post yet</span>
        <?php endif; ?>
    </ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\xLion\Desktop\FrontAndBackDev\Laravel7\forum\resources\views/posts/index.blade.php ENDPATH**/ ?>